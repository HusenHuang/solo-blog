title: Linux Yum安装JDK
date: '2019-09-10 16:36:18'
updated: '2019-09-10 16:36:18'
tags: [JDK安装]
permalink: /articles/2019/09/10/1568104578196.html
---
1. 查看系统有无安装JDK
```shell
	yum list installed |  grep  [java][jdk]
```

2. 卸载JDK环境
```shell
	yum -y remove java-1.6.0-openjdk*  //表时卸载所有openjdk相关文件输入
	yum -y remove tzdata-java.noarch   //卸载tzdata-java
```

3. 查看JDK版本
```shell
	yum search java |  grep -i --color jdk
```	

4. 安装JDK
```shell
	yum install -y java-1.8.0-openjdk java-1.8.0-openjdk-devel
	#或者如下命令，安装jdk1.8.0的所有文件
	yum install -y java-1.8.0-openjdk*
```

5. JDK默认安装路径
```shell
	/usr/lib/jvm
```

6. 修改/etc/profile文件
```shell
	JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.181-3.b13.el7_5.x86_64
	PATH=$PATH:$JAVA_HOME/bin  
	CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar  
	export JAVA_HOME  CLASSPATH  PATH 
```

7. 更新/etc/profile文件
```shell
	source /etc/profile
```
