title: XMind8破解
date: '2019-09-27 17:55:55'
updated: '2019-09-27 17:55:55'
tags: [XMind8破解]
permalink: /articles/2019/09/27/1569578154928.html
---
# XMind_8uw破解教程

82018.08.15 23:07:36字数 646阅读 79079

> 此篇针对windows版，如果是mac版，因为本人的mac使用的是mindnode，Xmind（Mac）具体破解教程文末有传送门，可以自行进行实验。

### 1.下载软件，下载破解包

官网地址：[XMind官网](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.xmind.cn%2Fdownload%2Fwin%2F)  
百度网盘地址：[破解包链接](https://links.jianshu.com/go?to=https%3A%2F%2Fpan.baidu.com%2Fs%2F1yy1aFllmxP3jn4-rOhS6dw) 密码：dofn

`网盘里就不帮你你们下载XMind了，官网有最新版，也可以根据自己的喜好来选择版本）`

![null](https://upload-images.jianshu.io/upload_images/9879225-d464e54ccf711d79?imageMogr2/auto-orient/strip|imageView2/2/w/975/format/webp)

帮助 ——> 关于XMind

  

此时软件显示未激活状态，OK，现在关闭XMind

### 2.打开网盘里分享的文件

![null](https://upload-images.jianshu.io/upload_images/9879225-0a5aac563348da9c?imageMogr2/auto-orient/strip|imageView2/2/w/762/format/webp)

找到这个“.jar”结尾的文件复制到XMind安装的根目录（所谓根目录就是你文件安装在哪个盘，安装在C盘就复制粘贴到C盘的根目录下）

我是安装在E盘，所以就复制到E盘根目录下

  

![null](https://upload-images.jianshu.io/upload_images/9879225-7375343baf36b64a?imageMogr2/auto-orient/strip|imageView2/2/w/879/format/webp)

### 3.添加host文件屏蔽防火墙

hosts目录：**C:\Windows\System32\drivers\etc**

选择用记事本打开，将

```css
0.0.0.0 www.xmind.net

```

这段内容，复制粘贴到本机的host中，保存并退出

  

![null](https://upload-images.jianshu.io/upload_images/9879225-49ec87c912e4e257?imageMogr2/auto-orient/strip|imageView2/2/w/753/format/webp)

* 如果遇到没有权限修改hosts文件  
    右键hosts文件——>属性——>安全——>编辑——>将“写入”开启
    
      
    
    ![null](https://upload-images.jianshu.io/upload_images/9879225-78facead076f53e3.png?imageMogr2/auto-orient/strip|imageView2/2/w/899/format/webp)
    
    修改权限.png
    

### 4.找到XMind安装目录

如果找不到，在桌面右键XMind属性

![null](https://upload-images.jianshu.io/upload_images/9879225-c8309d28f053f8d3?imageMogr2/auto-orient/strip|imageView2/2/w/543/format/webp)

打开文件所在位置

找到 “XMind.ini”文件，用记事本打开

  

![null](https://upload-images.jianshu.io/upload_images/9879225-7b0235a6075cccc7?imageMogr2/auto-orient/strip|imageView2/2/w/789/format/webp)

向里面添加  
`-javaagent:E:\XMindCrack.jar`  
保存并退出

![null](https://upload-images.jianshu.io/upload_images/9879225-0e1937411422547c?imageMogr2/auto-orient/strip|imageView2/2/w/774/format/webp)

原理同上，你XMind安装的是什么盘，就改成什么盘符，我安装的默认是E盘就不用变。

### 5.再次打开XMind

帮助 ——> 序列号 ——> 输入序列号

邮箱随便填，可以用你的QQ邮箱，只要格式正确，比如[12345678@qq.com](https://links.jianshu.com/go?to=mailto%3A12345678%40qq.com)

然后将序列号复制粘贴进去，验证，激活成功，就可以看到下面的场景

  

![null](https://upload-images.jianshu.io/upload_images/9879225-0870c84fe7ad024e?imageMogr2/auto-orient/strip|imageView2/2/w/609/format/webp)

  

![null](https://upload-images.jianshu.io/upload_images/9879225-49569b4018f879e9?imageMogr2/auto-orient/strip|imageView2/2/w/673/format/webp)

### Mac OS传送门

以上教程针对于Windows版本，如果是Mac电脑，请参考这篇教程：[https://www.jb51.net/softjc/624167.html](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.jb51.net%2Fsoftjc%2F624167.html)

#### Tips：

1.如果遇到激活失败，可以尝试一下重启电脑。

2.仅供学习交流使用，任何人不得以商业盈利为目的，否则一切责任自己承担！

3.私下试用，如果满意，请支持正版，谢谢合作！

原文链接：[http://note.youdao.com/noteshare?id=a376f4c247a21d7dc39c1c83d0a178a8&sub=8AAB500A10514A268447823DB0DF0A1A](https://links.jianshu.com/go?to=http%3A%2F%2Fnote.youdao.com%2Fnoteshare%3Fid%3Da376f4c247a21d7dc39c1c83d0a178a8%26sub%3D8AAB500A10514A268447823DB0DF0A1A)
