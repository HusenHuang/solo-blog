title: IDEA破解jrebel插件
date: '2019-09-16 16:12:19'
updated: '2019-09-16 16:15:10'
tags: [IDEA破解jrebel插件]
permalink: /articles/2019/09/16/1568621539458.html
---
# 插件下载:
	https://pan.baidu.com/s/1ptWSVMzdvNNtkCXjfUlBwg

问题：

码农日常中，热部署是必不可少的，而jrebel插件很好的实现热部署功能。

IDEA下载jrebel插件，可以免费试用15天，但之后就无法使用。因为Jrebel是收费的。

解决方法：

楼主也是百度了很多，得到了2种解决方法。这2种方法都可以，已亲测（第一个需要访问国外的网页，需要FQ，我是直接让国外的朋友帮我激活的，

所以这里没有细说，主要讲第二种方法）。

1.官网激活。地址https://my.jrebel.com，注意：在官网激活你需要有fackbook或者推特的账号，所以这个需要FQ。

2.破解Jrebel。

1）首先在github上下载一个exe文件，（用来破解jrebel）[https://github.com/ilanyu/ReverseProxy/releases/tag/v1.0](https://github.com/ilanyu/ReverseProxy/releases/tag/v1.0)

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190218114638289.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM4ODQ1NDkz,size_16,color_FFFFFF,t_70)

上图window 64系统的下载选择文件，大家可以根据系统自行选择下载。

2）双击运行下载的exe文件，出现如下图（不要关闭！）  
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190218114716543.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzM4ODQ1NDkz,size_16,color_FFFFFF,t_70)  
选择Connect to License Server 输入：

[http://127.0.0.1:8888/zsc](http://127.0.0.1:8888/zsc)

[zsc@123.com](mailto:zsc@123.com)

* 第二行http://127.0.0.1:8888/ 不变，zsc随意写，
    
* 第二行随意写个邮箱，格式正确即可。
    
* 然后点击确定按钮，激活成功！！！（此时，即可关闭exe窗口）
    

# **注意**

如果使用上面的激活地址出现 “Incorrect license server group URL.Contact license sever administrator.” 错误，是由于授权地址增加了GUID检测造成的，可以尝试使用下面的  
　激活地址：　  
　 [http://127.0.0.1:8888/88414687-3b91-4286-89ba-2dc813b107ce](http://127.0.0.1:8888/88414687-3b91-4286-89ba-2dc813b107ce)  
　 [http://127.0.0.1:8888/ff47a3ac-c11e-4cb2-836b-9b2b26101696](http://127.0.0.1:8888/ff47a3ac-c11e-4cb2-836b-9b2b26101696)  
　 [http://127.0.0.1:8888/11d221d1-5cf0-4557-b023-4b4adfeeb36a](http://127.0.0.1:8888/11d221d1-5cf0-4557-b023-4b4adfeeb36a)

> 转载自：  
> [https://www.cnblogs.com/zhengsc/p/8494066.html](https://www.cnblogs.com/zhengsc/p/8494066.html)  
> [https://www.cnblogs.com/wang1024/p/7211194.html](https://www.cnblogs.com/wang1024/p/7211194.html)
